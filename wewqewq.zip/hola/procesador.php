<?php

    if( isset($_POST["submit"]) && !empty($_POST["submit"]) ){

        $nom = $_POST['nombre'];
        $n1 = $_POST['nota1'];
        $n2 = $_POST['nota2'];
        $n3 = $_POST['nota3'];
        
        $n4 = $_POST['nota4'];
        $n5 = $_POST['nota5'];
        $n6 = $_POST['nota6'];
        
        $carrera = $_POST['carrera'];
        $promedio1 = (($n1*0.12)+($n2*0.21));
        $promedio2 = (($n3*0.12)+($n4*0.21));
        $promedio3 = (($n5*0.13)+($n6*0.21));

        $promedio = ($promedio1+$promedio2+$promedio3);
        
        if(!preg_match("/^[a-zA-Z]{3,15}$/", $_POST["nombre"]) || $nom ===""){
            echo "Error en nombre :";exit;

        }if(!preg_match("/^[0-9.]{3,15}$/", $_POST["nota1"]) || $n1 ==="" || $n1 <0 || $n1 >7.0){
                echo "Error en nota 1 :";exit;

        }if(!preg_match("/^[0-9.]{3,15}$/", $_POST["nota2"]) || $n2 ==="" || $n2 <0 || $n2 >7.0){
                echo "Error en nota 2 :";exit;

        }if(!preg_match("/^[0-9.]{3,15}$/", $_POST["nota3"]) || $n3 ==="" || $n3 <0 || $n3 >7.0){
                echo "Error en nota 3 :";exit;

        }if(!preg_match("/^[0-9.]{3,15}$/", $_POST["nota4"]) || $n4 ==="" || $n4 <0 || $n4 >7.0){
                echo "Error en nota 4 :";exit;

        }if(!preg_match("/^[0-9.]{3,15}$/", $_POST["nota5"]) || $n5 ==="" || $n5 <0 || $n5 >7.0){
                echo "Error en nota 5 :";exit;

        }if(!preg_match("/^[0-9.]{3,15}$/", $_POST["nota6"]) || $n6 ==="" || $n6 <0 || $n6 >7.0){
                echo "Error en nota 6 :";exit;


            }if($promedio >= 4.0){
                echo '<script language="javascript">alert("Has Aprobado la Asignaturas! ");</script>';
            }else{
                echo '<script language="javascript">alert("Has REPROBADO! ");</script>';
            
                    
            }
        
        
        echo "<br><h1>Estas son las notas</h1><br />";

        echo "<br><b>El nombre del estudiante es</b>: " .$nom. "<br />";

        echo "<br><b>Tu carrera es</b>: " .$carrera. "<br />";

        echo "<br><b>Tu promedio de la primera unidad es</b>: " .$promedio1. "<br />";

        echo "<br><b>Tu promedio de la segunda unidad es</b>: " .$promedio2. "<br />";

        echo "<br><b>Tu promedio de la tercera unidad es</b>: " .$promedio3. "<br />";

        echo "<br><b>Tu nota1 de la unidad es</b>: " .$n1. "<br />";

        echo "<br><b>Tu nota2 de la unidad es</b>: " .$n2. "<br />";

        echo "<br><b>Tu nota3 de la unidad es</b>: " .$n3. "<br />";

        echo "<br><b>Tu nota4 de la unidad es</b>: " .$n4. "<br />";

        echo "<br><b>Tu nota5 de la unidad es</b>: " .$n5. "<br />";

        echo "<br><b>Tu nota6 de la unidad es</b>: " .$n6. "<br />";

        echo "<br><b>El promedio es<b>: " .round($promedio,1). "<br />";

        }
?>
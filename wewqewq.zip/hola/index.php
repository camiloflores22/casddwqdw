<!DOCTYPE html>
<html lang="en">
<head>
    <link href="./assets/estilos/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet"  href="decorador.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
</head>
<center>
<body>
    <div>
        
        <td><img src="./assets/imagenes/cft.jpg" alt="" width="8%"></td>⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
        <td> <a href="">Inicio</a></td>⠀⠀⠀⠀⠀⠀⠀
        <td> <a href="">Admision</a></td>⠀⠀⠀⠀⠀⠀⠀⠀
        <td> <a href="">Carrera</a></td> ⠀⠀⠀⠀⠀⠀⠀
        <td> <a href="">Contactanos</a></td> ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
   

        <input  class="" type="search" placeholder="Buscar tu carrera" value="">
        <button class="btn btn-outline-success" type="submit">Buscar</button>

        <h1>Carculadora de notas</h1>
    <form action="procesador.php" method="POST">
    
    <h2>Registrate</h2>
        <label for="">Nombre de Estudiante:</label><br>
        <input type="text" name="nombre" size="15"><br><br>

        <select name="carrera" id="carrera"> 
        <option value="ninguno">Asignatura</option>
        <option value="geologia">TNS Geología</option>
        <option value="minas">TNS en Minas</option>
        <option value="metales">TNS en Metales</option>
        <option value="informatica" >TNS en Informática</option>
    </select>

        <h3>Unidad 1<h3>
        <h4>33%<h4>

        <label for="">Nota1 12%:</label><br>
        <input type="text" name="nota1" size="9"><br><br>

        <label for="">Nota2 21%:</label><br>
        <input type="text" name="nota2" size="9"><br><br>

        <h3>Unidad 2<h3>
        <h4>33%<h4>

        <label for="">Nota3 12%:</label><br>
        <input type="text" name="nota3" size="9"><br><br>


        <label for="">Nota4 21%:</label><br>
        <input type="text" name="nota4" size="9"><br><br>

        <h3>Unidad 3<h3>
        <h4>34%<h4>

        <label for="">Nota5 13%:</label><br>
        <input type="text" name="nota5" size="9"><br><br>


        <label for="">Nota6 21%:</label><br>
        <input type="text" name="nota6" size="9"><br><br>

        <input class="btn btn-primary" type="submit" value="Calcule" name="submit">

    </form>
</body>
</center>
</html>